    tmp256 = _mm256_permutevar8x32_ps(tmp0, _mm256_set_epi32(2,0,4,5,6,7,1,3));
    DO_NOT_TOUCH(tmp0);
