    tmp256 = _mm256_permutevar8x32_ps(tmp0, _mm256_set_epi32(2,0,4,1,6,3,5,7));
    DO_NOT_TOUCH(tmp0);
