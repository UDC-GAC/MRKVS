    tmp256 = _mm256_permutevar8x32_ps(tmp0, _mm256_set_epi32(0,2,4,6,3,5,7,1));
    DO_NOT_TOUCH(tmp0);
