    tmp256 = _mm256_permutevar8x32_ps(tmp0, _mm256_set_epi32(1,7,6,4,5,3,0,2));
    DO_NOT_TOUCH(tmp0);
